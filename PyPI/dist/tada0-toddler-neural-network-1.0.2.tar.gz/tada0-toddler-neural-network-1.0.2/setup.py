from setuptools import setup

setup(
    name='tada0-toddler-neural-network',
    version='1.0.2',
    scripts=['toddlerneuron'],
    install_requires=[
        'numpy',
        'time'
    ]
)
